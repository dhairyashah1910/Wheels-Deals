import { Container, Grid, List } from '@mui/material';
import React from 'react';
import { Box } from '@mui/system';

const footerBg = {
    color: '#C1C1C1',
    background: `url("https://i.ibb.co/pdprFvx/letter-bg.png")`,
    backgroundPosition: 'center',
    backgroundSize: 'cover',
    backgroundColor: 'rgba(29, 88, 78, 0.9)',
    backgroundBlendMode: 'darken, luminosity'
}

const Footer = () => {
    return (
        <footer style={footerBg}>
            <Container>
                <Grid container spacing={3} sx={{ my: 3 }}>
                    <Grid item xs={12} sm={12} md={6} lg={3}>
                        <List>
                            <Box style={{ display: 'flex' }}>
                                <img style={{ width: '100%', marginRight: '10px' }} src="https://i.ibb.co/gRfcV3C/car-3.png" alt="" />
                            </Box>
                            <Box style={{ display: 'flex', margin: '10px auto' }}>
                                <img style={{ width: '100%', marginRight: '10px' }} src="https://i.ibb.co/JnBB6Bn/car-5.png" alt="" />
                            </Box>
                            <Box style={{ display: 'flex' }}>
                                <img style={{ width: '100%', marginRight: '10px' }} src="https://i.ibb.co/0Ch5ZBv/car-2.png" alt="" />
                            </Box>
                        </List>
                    </Grid>
                    <Grid item xs={12} sm={12} md={6} lg={3}>
                        <h1> About Us </h1>
                        <h3> Welcome to Wheels & Deals your trusted destination for high-quality, affordable second-hand cars. 
                            Established with a passion for cars and a commitment to customer satisfaction, we aim to make buying a pre-owned vehicle as seamless and stress-free as possible. 
                            Whether you're a first-time buyer or looking for an upgrade, we have something for everyone.
                        </h3>
                    </Grid>
                </Grid>
                
            </Container>
        </footer>
    );
};

export default Footer;