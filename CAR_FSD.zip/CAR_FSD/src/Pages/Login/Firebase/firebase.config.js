// const firebaseConfig = {
//     apiKey: `${process.env.REACT_APP_FIREBASE_API_KEY}`,
//     authDomain: `${process.env.REACT_APP_FIREBASE_AUTH_DOMAIN}`,
//     projectId: `${process.env.REACT_APP_FIREBASE_PROJECT_ID}`,
//     storageBucket: `${process.env.REACT_APP_FIREBASE_STORAGE_BUCKET}`,
//     messagingSenderId: `${process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID}`,
//     appId: `${process.env.REACT_APP_FIREBASE_APP_ID}`
// };

const firebaseConfig = {
    apiKey: "AIzaSyAqnbK03K5763Fq68fAokesiYdk3l7DSbc",
    authDomain: "car-selling-website-336db.firebaseapp.com",
    projectId: "car-selling-website-336db",
    storageBucket: "car-selling-website-336db.appspot.com",
    messagingSenderId: "374172246535",
    appId: "1:374172246535:web:683fcce3a48fdcd70140a2"
  };

export default firebaseConfig;